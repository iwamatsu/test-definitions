#!/bin/sh
BASE_DIR=$(realpath $(dirname $0))
cd $BASE_DIR
. ./kselftest/runner.sh
ROOT=$PWD
if [ "$1" = "--summary" ]; then
  logfile=$BASE_DIR/output.log
  cat /dev/null > $logfile
fi
[ -w /dev/kmsg ] && echo "kselftest: Running tests in x86" >> /dev/kmsg
cd x86
run_many	\
	"single_step_syscall_32"	\
	"sysret_ss_attrs_32"	\
	"syscall_nt_32"	\
	"test_mremap_vdso_32"	\
	"check_initial_reg_state_32"	\
	"sigreturn_32"	\
	"iopl_32"	\
	"mpx-mini-test_32"	\
	"ioperm_32"	\
	"protection_keys_32"	\
	"test_vdso_32"	\
	"test_vsyscall_32"	\
	"mov_ss_trap_32"	\
	"entry_from_vm86_32"	\
	"syscall_arg_fault_32"	\
	"test_syscall_vdso_32"	\
	"unwind_vdso_32"	\
	"test_FCMOV_32"	\
	"test_FCOMI_32"	\
	"test_FISTTP_32"	\
	"vdso_restorer_32"	\
	"ldt_gdt_32"	\
	"ptrace_syscall_32"	\
	"single_step_syscall_64"	\
	"sysret_ss_attrs_64"	\
	"syscall_nt_64"	\
	"test_mremap_vdso_64"	\
	"check_initial_reg_state_64"	\
	"sigreturn_64"	\
	"iopl_64"	\
	"mpx-mini-test_64"	\
	"ioperm_64"	\
	"protection_keys_64"	\
	"test_vdso_64"	\
	"test_vsyscall_64"	\
	"mov_ss_trap_64"	\
	"fsgsbase_64"	\
	"sysret_rip_64"	\
	"ldt_gdt_64"	\
	"ptrace_syscall_64"
cd $ROOT
